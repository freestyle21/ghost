##篮球

## 运球
变向

![](yunqiu/1.gif)

胯下背绕式组合运球

![](yunqiu/2.gif)

延伸膝盖宽度运球

![](yunqiu/3.gif)

![](yunqiu/4.gif)

![](yunqiu/5.gif)

![](yunqiu/6.gif)

![](yunqiu/7.gif)

![](yunqiu/8.gif)

![](yunqiu/9.gif)

![](yunqiu/10.gif)

![](yunqiu/11.gif)

![](yunqiu/12.gif)

![](yunqiu/13.gif)

## 过人

cross over

![](guoren/crossover.gif)

![](guoren/crossover1.gif)

![](guoren/crossover2.gif)

拜佛

![](guoren/baifo1.gif)

![](guoren/baifo2.gif)

![](guoren/baifo3.gif)

交叉步

![](guoren/jiaocha3.gif)

![](guoren/jiaocha1.gif)

过人

![](guoren/guoren1.gif)

![](guoren/guoren2.gif)

![](guoren/guoren3.gif)

![](guoren/guoren4.gif)

![](guoren/guoren5.gif)

![](guoren/guoren6.gif)

![](guoren/guoren7.gif)

![](guoren/jiaoshou.gif)

![](guoren/jiaoshou1.gif)

![](guoren/jiaoshou2.gif)

交叉步

拜佛

![](guoren/baifo1.gif)

![](guoren/baifo2.gif)


## 中投

![](toulan/2.gif)

1.垫脚屈膝。2 翘臀。3 斜背。4 球在胸或腰的shot pocket。 5 球起人起，跳投

![](toulan/1.gif)

![](xuexi/paotou.gif)

![](xuexi/paotou1.gif)


## 连贯动作

![](xuexi/xuexi1.gif)

![](xuexi/xuexi2.gif)


